$(function(e) {
	$('#example').DataTable();
} );